

class Data:

    USERNAME = "Admin"
    PASSWORD = "admin123"