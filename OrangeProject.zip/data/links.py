

class Links:

    BASE_URL = "https://opensource-demo.orangehrmlive.com/web/index.php"
    LOGIN_PAGE = f"{BASE_URL}/auth/login"
    ADMIN_PAGE = f"{BASE_URL}/admin/viewSystemUsers"
    DASHBOARD_PAGE = f"{BASE_URL}/dashboard/index"