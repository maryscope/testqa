from pages.basePage import BasePage
from data.links import Links


class DashboardPage(BasePage):

    PAGE_URL = Links.DASHBOARD_PAGE